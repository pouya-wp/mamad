"""Payment snapshots are source facts, separate from the ERP clearing account."""
import base64
import gzip
import io
import json
from decimal import Decimal, InvalidOperation

MAX_DECODED_BYTES = 2 * 1024 * 1024


def decode_report(stdout):
    text = stdout.strip()
    if not text.startswith("GZIP:") or len(text) > 65536:
        raise ValueError("Invalid payment report envelope")
    compressed = base64.b64decode(text[5:], validate=True)
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
        data = stream.read(MAX_DECODED_BYTES + 1)
    if len(data) > MAX_DECODED_BYTES:
        raise ValueError("Payment report is too large")
    return json.loads(data.decode("utf-8-sig"))


def money(value):
    if isinstance(value, bool) or value is None:
        raise ValueError("Invalid source amount")
    try:
        amount = Decimal(str(value))
    except InvalidOperation as error:
        raise ValueError("Invalid source amount") from error
    if not amount.is_finite() or abs(amount) > Decimal("1000000000000"):
        raise ValueError("Invalid source amount")
    return amount


def normalize_payment(header, rows, catalog):
    """IdAmel 99 is the verified receivable posting, never money collected.

    Closed flags also occur on credit invoices. Only reconciled receipt amounts
    can establish Paid. Unknown methods or unbalanced entries stay Unknown.
    """
    total = money(header["total"])
    if total < 0:
        raise ValueError("Negative source invoice total")
    received = Decimal(0)
    credit = Decimal(0)
    methods = {}
    unknown = False
    for row in rows:
        amount = money(row["amount"])
        if amount < 0:
            unknown = True
            continue
        method = int(row["method"] or 0)
        if method == 99:
            credit += amount
            continue
        label = catalog.get(method)
        if not label:
            unknown = True
            continue
        received += amount
        methods[label] = methods.get(label, Decimal(0)) + amount
    outstanding = max(total - received, Decimal(0))
    # A discrepancy can be an in-progress source transaction, a fee or an
    # unsupported payment posting. It must not establish a settled invoice.
    if received > total or (header.get("closed") and received + credit != total):
        unknown = True
    if header.get("cancelled"):
        status = "Cancelled"
    elif unknown:
        status = "Unknown"
    elif total > 0 and outstanding == 0:
        status = "Paid"
    elif received > 0:
        status = "Partial"
    elif credit > 0:
        status = "Credit"
    else:
        status = "Unpaid"
    basis = "Invoice"
    account_balance = None
    if credit and status != "Cancelled" and header.get("account_verified"):
        account_balance = money(header["account_balance"])
        if not unknown and account_balance <= 0:
            # All receivables for this customer, including unposted daily
            # invoices, are cleared. No FIFO allocation is invented.
            received = total
            outstanding = Decimal(0)
            status = "Paid"
            basis = "Customer Account"
            methods["تسویه حساب مشتری"] = credit
        elif money(header.get("unallocated_receipts", 0)) > 0:
            # Source receipts have Factor=0. The remaining customer debt is
            # known, but its allocation to this particular bill is not.
            outstanding = None
            basis = "Unallocated"
    return {
        "status": status,
        "total": float(total),
        "received": None if unknown or status == "Cancelled" else float(received),
        "outstanding": None if unknown or status == "Cancelled" or outstanding is None else float(outstanding),
        "methods": [
            {"mode_of_payment": name, "amount": float(amount)}
            for name, amount in sorted(methods.items()) if amount and status != "Cancelled"
        ],
        "credit": float(credit),
        "basis": basis,
        "account_balance": float(account_balance) if account_balance is not None else None,
    }
