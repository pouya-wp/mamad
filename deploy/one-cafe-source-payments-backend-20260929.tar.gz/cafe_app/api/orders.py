import frappe
from erpnext.accounts.doctype.sales_invoice.sales_invoice import make_sales_return
from frappe import _
from frappe.utils import cint, flt

from cafe_app.source_catalog import display_item_name
from cafe_app.sales_source import order_payment_modes, order_payments
from cafe_app.source_payments import source_key, snapshots, unknown_snapshot, for_invoice, payment_overview
from cafe_app.utils import get_cafe_settings


@frappe.whitelist()
def list_orders(from_date=None, to_date=None, search=None, start=0, limit=50):
	settings = get_cafe_settings()
	filters = {"docstatus": 1, "company": settings.company}
	if from_date and to_date:
		filters["posting_date"] = ["between", [from_date, to_date]]

	or_filters = None
	if search:
		or_filters = {"name": ["like", f"%{search}%"], "remarks": ["like", f"%{search}%"]}

	orders = frappe.get_all(
		"Sales Invoice",
		filters=filters,
		or_filters=or_filters,
		fields=[
			"name",
			"posting_date",
			"posting_time",
			"base_grand_total",
			"is_return",
			"return_against",
			"status",
			"remarks",
			"owner",
		],
		order_by="posting_date desc, posting_time desc",
		start=cint(start),
		limit=cint(limit),
	)

	names = [o.name for o in orders] or [""]
	modes = {}
	for parent, mode in frappe.get_all(
		"Sales Invoice Payment", filters={"parent": ["in", names]}, fields=["parent", "mode_of_payment"], as_list=True
	):
		modes.setdefault(parent, []).append(mode)
	counts = dict(
		frappe.db.sql(
			"select parent, sum(qty) from `tabSales Invoice Item` where parent in %(names)s group by parent",
			{"names": names},
		)
	)
	source = snapshots(source_key(o.remarks) for o in orders if not o.is_return)
	for o in orders:
		o.payment_modes = order_payment_modes(o, modes.get(o.name, []))
		key = source_key(o.remarks)
		if key and not o.is_return:
			o.source_payment = source.get(key, unknown_snapshot())
			if o.source_payment.get("total") is not None:
				o.original_grand_total = o.base_grand_total
				o.base_grand_total = o.source_payment["total"]
			if o.source_payment.get("items"):
				o.items_count = sum(item["qty"] for item in o.source_payment["items"])
			o.payment_modes = [p["mode_of_payment"] for p in o.source_payment["methods"]]
			if o.source_payment.get("credit") and o.source_payment["basis"] != "Customer Account":
				o.payment_modes.append("نسیه")
			if not o.payment_modes:
				o.payment_modes = ["سپهریار؛ روش نامشخص"]
		if not o.get("items_count"):
			o.items_count = counts.get(o.name, 0)
		o.owner_name = frappe.utils.get_fullname(o.owner)
	return orders


@frappe.whitelist()
def order_totals(from_date=None, to_date=None, search=None):
	"""Totals for the complete filtered set, independent of list pagination."""
	settings = get_cafe_settings()
	params = {"company": settings.company}
	conditions = ["docstatus = 1", "company = %(company)s"]
	if from_date and to_date:
		conditions.append("posting_date between %(from_date)s and %(to_date)s")
		params.update({"from_date": from_date, "to_date": to_date})
	if search:
		conditions.append("(name like %(search)s or remarks like %(search)s)")
		params["search"] = f"%{search}%"
	row = frappe.db.sql(
		f"""
		select
			coalesce(sum(case when is_return = 0 then 1 else 0 end), 0) as order_count,
			coalesce(sum(base_grand_total), 0) as revenue,
			coalesce(sum(case when is_return = 1 then 1 else 0 end), 0) as returns
		from `tabSales Invoice`
		where {' and '.join(conditions)}
		""",
		params,
		as_dict=True,
	)[0]
	orders = frappe.db.sql(f"select remarks,is_return,base_grand_total from `tabSales Invoice` where {' and '.join(conditions)}", params, as_dict=True)
	source = snapshots(source_key(order.remarks) for order in orders if not order.is_return)
	revenue = 0
	count = 0
	for order in orders:
		payment = source.get(source_key(order.remarks)) if not order.is_return else None
		cancelled = payment and payment["status"] == "Cancelled"
		if not cancelled:
			revenue += payment["total"] if payment and payment["total"] is not None else order.base_grand_total
			count += not order.is_return
	return {"count": count, "revenue": flt(revenue), "returns": cint(row.returns),
		"source_payments": payment_overview(orders)}


@frappe.whitelist()
def get_order(name):
	doc = frappe.get_doc("Sales Invoice", name)
	doc.check_permission("read")
	source = for_invoice(doc)
	items = source.get("items") if source else None
	projected = bool(items and source["total"] is not None)
	item_total = sum(item["amount"] for item in items) if projected else doc.base_total
	grand_total = source["total"] if projected else doc.base_grand_total
	return {
		"name": doc.name,
		"posting_date": doc.posting_date,
		"posting_time": doc.posting_time,
		"status": doc.status,
		"is_return": doc.is_return,
		"return_against": doc.return_against,
		"remarks": doc.remarks,
		"owner_name": frappe.utils.get_fullname(doc.owner),
		"total": item_total,
		"discount_amount": max(item_total - grand_total, 0) if projected else doc.base_discount_amount,
		"source_extra_amount": max(grand_total - item_total, 0) if projected else 0,
		"grand_total": grand_total,
		"source_items_current": projected,
		"original_grand_total": doc.base_grand_total,
		"items": items if projected else [
			{"item_code": i.item_code, "item_name": display_item_name(i.item_code, i.item_name), "qty": i.qty, "rate": i.base_rate, "amount": i.base_amount}
			for i in doc.items
		],
		"payments": order_payments(doc),
		"source_payment": source,
		"has_return": bool(frappe.db.exists("Sales Invoice", {"return_against": doc.name, "docstatus": 1})),
	}


@frappe.whitelist()
def return_order(name, reason=None):
	"""Full refund: a submitted credit note that also puts the ingredients back in stock."""
	if source_key(frappe.db.get_value("Sales Invoice", name, "remarks")):
		frappe.throw(_("مرجوعی فاکتور سپهریار باید در خود سپهریار ثبت شود تا اقلام و مبلغ اصلی آن درست بماند"))
	if frappe.db.exists("Sales Invoice", {"return_against": name, "docstatus": 1}):
		frappe.throw(_("این سفارش قبلاً مرجوع شده"))

	credit_note = make_sales_return(name)
	credit_note.remarks = reason or _("مرجوعی سفارش {0}").format(name)
	credit_note.insert()
	credit_note.submit()
	return credit_note.name
