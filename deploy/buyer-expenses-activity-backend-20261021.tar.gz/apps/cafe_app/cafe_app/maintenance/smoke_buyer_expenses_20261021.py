"""Exercise expense and advance posting as a buyer, then roll back every write."""

import frappe

from cafe_app.api import buyer_expenses


def run():
	previous = frappe.session.user
	result = None
	try:
		frappe.set_user("restaurant.buyer@onecafe.beyondex.one")
		choices = buyer_expenses.options()
		if not choices["accounts"] or not choices["employees"]:
			frappe.throw("Expense account or active employee missing")
		expense = buyer_expenses.record_entry(
			"Restaurant", "Expense", 10, "Cash",
			account=choices["accounts"][0].name, note="آزمون موقت؛ برگشت تراکنش",
		)
		advance = buyer_expenses.record_entry(
			"Cafe", "Advance", 10, "Cash",
			employee=choices["employees"][0].name, note="آزمون موقت؛ برگشت تراکنش",
		)
		result = {"expense": expense, "advance": advance}
	finally:
		frappe.db.rollback()
		frappe.set_user(previous)
	if frappe.db.exists("Cafe Buyer Expense", result["expense"]["name"]) or frappe.db.exists("Cafe Buyer Expense", result["advance"]["name"]):
		frappe.throw("Smoke records were not rolled back")
	if frappe.db.exists("Journal Entry", result["expense"]["journal_entry"]) or frappe.db.exists("Journal Entry", result["advance"]["journal_entry"]):
		frappe.throw("Smoke journal entries were not rolled back")
	return {**result, "rolled_back": True}
